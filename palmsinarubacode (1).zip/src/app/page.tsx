import Link from "next/link";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-ocean-950 via-ocean-800 to-ocean-600 px-6 text-center text-white">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-sand-400">
        Palms in Aruba
      </p>
      <h1 className="mt-3 max-w-xl text-4xl font-semibold tracking-tight">
        Car Detailing, Brought to You.
      </h1>
      <p className="mt-3 max-w-md text-ocean-100">
        Premium mobile car detailing in Aruba. The public booking site is coming soon.
      </p>
      <Link
        href="/admin"
        className="mt-8 rounded-xl bg-white px-6 py-3 text-sm font-medium text-ocean-900 hover:bg-ocean-50"
      >
        Go to Business Dashboard
      </Link>
    </div>
  );
}
