import { getDashboardData } from "@/lib/dashboard";
import { StatCard, Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatAWG, formatDateTime, titleCase } from "@/lib/utils";
import Link from "next/link";

const statusTone: Record<string, "neutral" | "positive" | "warning" | "negative" | "info"> = {
  INQUIRY: "neutral",
  QUOTED: "info",
  BOOKED: "info",
  CONFIRMED: "info",
  IN_PROGRESS: "warning",
  COMPLETED: "positive",
  CANCELLED: "negative",
  NO_SHOW: "negative",
};

function TargetBar({ label, actual, target, format }: { label: string; actual: number; target: number; format: (n: number) => string }) {
  const pct = target > 0 ? Math.min(100, (actual / target) * 100) : 0;
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="text-muted">{label}</span>
        <span className="font-medium text-ocean-950">
          {format(actual)} <span className="text-muted font-normal">/ {format(target)}</span>
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-ocean-50">
        <div
          className="h-full rounded-full bg-ocean-600"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export default async function DashboardPage() {
  const data = await getDashboardData();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">Dashboard</h1>
        <p className="text-sm text-muted">
          Leads → Customers → Revenue → Profit → Repeat Customers
        </p>
      </div>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">Today</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Today's Appointments" value={String(data.today.appointments.length)} />
          <StatCard label="Today's Revenue" value={formatAWG(data.today.revenue)} />
          <StatCard label="Completed Jobs" value={String(data.today.completedJobs)} />
          <StatCard label="Expected Revenue" value={formatAWG(data.today.expectedRevenue)} />
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">This Week</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          <StatCard label="Jobs Completed" value={String(data.week.jobsCompleted)} />
          <StatCard label="Revenue" value={formatAWG(data.week.revenue)} />
          <StatCard label="Expenses" value={formatAWG(data.week.expenses)} />
          <StatCard label="Profit" value={formatAWG(data.week.profit)} />
          <StatCard label="New Customers" value={String(data.week.newCustomers)} />
          <StatCard label="Repeat Customers" value={String(data.week.repeatCustomers)} />
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">This Month</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Revenue" value={formatAWG(data.month.revenue)} />
          <StatCard label="Expenses" value={formatAWG(data.month.expenses)} />
          <StatCard label="Profit" value={formatAWG(data.month.profit)} />
          <StatCard label="Customers" value={String(data.month.customers)} />
          <StatCard label="Average Ticket" value={formatAWG(data.month.averageTicket)} />
          <StatCard label="Repeat Customer %" value={`${data.month.repeatCustomerPct.toFixed(0)}%`} />
          <StatCard label="Marketing Leads" value={String(data.month.leads)} />
          <StatCard label="Conversion Rate" value={`${data.month.conversionRate.toFixed(0)}%`} />
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">Business Health</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Total Customers" value={String(data.health.totalCustomers)} />
          <StatCard label="Active Recurring" value={String(data.health.activeRecurring)} />
          <StatCard label="Total Revenue" value={formatAWG(data.health.totalRevenue)} />
          <StatCard label="Total Expenses" value={formatAWG(data.health.totalExpenses)} />
          <StatCard label="Net Profit" value={formatAWG(data.health.netProfit)} />
          <StatCard label="Avg Customer Value" value={formatAWG(data.health.avgCustomerValue)} />
          <StatCard label="Avg Job Value" value={formatAWG(data.health.avgJobValue)} />
        </div>
      </section>

      {data.target && (
        <section>
          <Card>
            <CardHeader className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold text-ocean-950">
                Target: {data.target.label} — Actual vs Target
              </CardTitle>
              <Link href="/admin/settings" className="text-xs text-ocean-600 hover:underline">
                Edit targets
              </Link>
            </CardHeader>
            <CardContent className="space-y-4">
              <TargetBar label="Revenue" actual={data.target.actualRevenue} target={data.target.targetRevenue} format={formatAWG} />
              <TargetBar label="Expenses" actual={data.target.actualExpenses} target={data.target.targetExpenses} format={formatAWG} />
              <TargetBar label="Profit" actual={data.target.actualProfit} target={data.target.targetProfit} format={formatAWG} />
              <TargetBar
                label="Customers"
                actual={data.target.actualCustomers}
                target={data.target.targetCustomers ?? 0}
                format={(n) => String(n)}
              />
              <TargetBar
                label="Repeat Customers"
                actual={data.target.actualRepeatCustomers}
                target={data.target.targetRepeatCustomers ?? 0}
                format={(n) => String(n)}
              />
            </CardContent>
          </Card>
        </section>
      )}

      <section>
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold text-ocean-950">Today&apos;s Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            {data.today.appointments.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted">No appointments scheduled for today.</p>
            ) : (
              <div className="divide-y divide-border">
                {data.today.appointments.map((a) => (
                  <Link
                    key={a.id}
                    href={`/admin/appointments/${a.id}`}
                    className="flex items-center justify-between py-3 hover:bg-ocean-50/50"
                  >
                    <div>
                      <p className="text-sm font-medium text-ocean-950">{a.customer.fullName}</p>
                      <p className="text-xs text-muted">
                        {a.vehicle.make} {a.vehicle.model} · {formatDateTime(a.scheduledDate)}
                      </p>
                    </div>
                    <Badge tone={statusTone[a.status]}>{titleCase(a.status)}</Badge>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
