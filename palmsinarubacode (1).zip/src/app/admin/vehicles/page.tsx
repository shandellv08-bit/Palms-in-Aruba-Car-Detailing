import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { formatDate, titleCase } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default async function VehiclesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;

  const vehicles = await prisma.vehicle.findMany({
    where: q
      ? {
          OR: [
            { make: { contains: q, mode: "insensitive" } },
            { model: { contains: q, mode: "insensitive" } },
            { licensePlate: { contains: q, mode: "insensitive" } },
            { customer: { fullName: { contains: q, mode: "insensitive" } } },
          ],
        }
      : undefined,
    include: { customer: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">Vehicles</h1>
        <p className="text-sm text-muted">{vehicles.length} total</p>
      </div>

      <form className="flex gap-3">
        <Input name="q" placeholder="Search make, model, plate, owner..." defaultValue={q} className="max-w-sm" />
        <Button type="submit" variant="outline">
          Search
        </Button>
      </form>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-ocean-50/50 text-left text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3">Vehicle</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Owner</th>
              <th className="px-4 py-3">Plate</th>
              <th className="px-4 py-3">Last Detailed</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {vehicles.map((v) => (
              <tr key={v.id} className="hover:bg-ocean-50/40">
                <td className="px-4 py-3 font-medium text-ocean-950">
                  {v.year ? `${v.year} ` : ""}
                  {v.make} {v.model}
                </td>
                <td className="px-4 py-3 text-muted">{titleCase(v.vehicleType)}</td>
                <td className="px-4 py-3">
                  <Link href={`/admin/customers/${v.customerId}`} className="text-ocean-800 hover:underline">
                    {v.customer.fullName}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">{v.licensePlate ?? "—"}</td>
                <td className="px-4 py-3 text-muted">{formatDate(v.lastDetailed)}</td>
              </tr>
            ))}
            {vehicles.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-muted">
                  No vehicles found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
