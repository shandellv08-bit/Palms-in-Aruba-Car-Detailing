import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Select } from "@/components/ui/input";
import { formatAWG, formatDate, titleCase } from "@/lib/utils";
import { CUSTOMER_STATUSES } from "@/lib/enums";

const statusTone: Record<string, "neutral" | "positive" | "warning" | "negative" | "info"> = {
  LEAD: "neutral",
  NEW: "info",
  ACTIVE: "positive",
  RECURRING: "positive",
  INACTIVE: "warning",
  VIP: "info",
};

export default async function CustomersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string }>;
}) {
  const { q, status } = await searchParams;

  const customers = await prisma.customer.findMany({
    where: {
      AND: [
        status ? { status: status as never } : {},
        q
          ? {
              OR: [
                { fullName: { contains: q, mode: "insensitive" } },
                { phone: { contains: q, mode: "insensitive" } },
                { email: { contains: q, mode: "insensitive" } },
              ],
            }
          : {},
      ],
    },
    include: {
      vehicles: { select: { id: true } },
      payments: { select: { amount: true } },
      appointments: { select: { id: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-ocean-950">Customers</h1>
          <p className="text-sm text-muted">{customers.length} total</p>
        </div>
        <Button asChild>
          <Link href="/admin/customers/new">+ New Customer</Link>
        </Button>
      </div>

      <form className="flex flex-wrap gap-3">
        <Input
          name="q"
          placeholder="Search name, phone, email..."
          defaultValue={q}
          className="max-w-xs"
        />
        <Select name="status" defaultValue={status} className="max-w-[160px]">
          <option value="">All statuses</option>
          {CUSTOMER_STATUSES.map((s) => (
            <option key={s} value={s}>
              {titleCase(s)}
            </option>
          ))}
        </Select>
        <Button type="submit" variant="outline">
          Filter
        </Button>
      </form>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-ocean-50/50 text-left text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Vehicles</th>
              <th className="px-4 py-3">Total Spent</th>
              <th className="px-4 py-3">Acquired</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {customers.map((c) => {
              const totalSpent = c.payments.reduce((sum, p) => sum + Number(p.amount), 0);
              return (
                <tr key={c.id} className="hover:bg-ocean-50/40">
                  <td className="px-4 py-3">
                    <Link href={`/admin/customers/${c.id}`} className="font-medium text-ocean-800 hover:underline">
                      {c.fullName}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-muted">{c.phone}</td>
                  <td className="px-4 py-3">
                    <Badge tone={statusTone[c.status]}>{titleCase(c.status)}</Badge>
                  </td>
                  <td className="px-4 py-3 text-muted">{c.vehicles.length}</td>
                  <td className="px-4 py-3 font-medium text-ocean-950">{formatAWG(totalSpent)}</td>
                  <td className="px-4 py-3 text-muted">{formatDate(c.dateAcquired)}</td>
                </tr>
              );
            })}
            {customers.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted">
                  No customers found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
