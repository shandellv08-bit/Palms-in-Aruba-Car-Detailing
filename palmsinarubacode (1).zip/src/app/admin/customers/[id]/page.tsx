import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { formatAWG, formatDate, titleCase } from "@/lib/utils";
import { VEHICLE_TYPES } from "@/lib/enums";
import { addVehicle, deleteVehicle, deleteCustomer } from "../actions";

const apptStatusTone: Record<string, "neutral" | "positive" | "warning" | "negative" | "info"> = {
  INQUIRY: "neutral",
  QUOTED: "info",
  BOOKED: "info",
  CONFIRMED: "info",
  IN_PROGRESS: "warning",
  COMPLETED: "positive",
  CANCELLED: "negative",
  NO_SHOW: "negative",
};

export default async function CustomerDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const customer = await prisma.customer.findUnique({
    where: { id },
    include: {
      vehicles: { orderBy: { createdAt: "desc" } },
      payments: { orderBy: { paidAt: "desc" } },
      appointments: {
        include: { vehicle: true },
        orderBy: { scheduledDate: "desc" },
        take: 10,
      },
    },
  });

  if (!customer) notFound();

  const totalSpent = customer.payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const addVehicleWithId = addVehicle.bind(null, customer.id);
  const deleteCustomerWithId = deleteCustomer.bind(null, customer.id);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold text-ocean-950">{customer.fullName}</h1>
            <Badge>{titleCase(customer.status)}</Badge>
          </div>
          <p className="text-sm text-muted">
            {customer.phone} {customer.email && `· ${customer.email}`}
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link href={`/admin/customers/${customer.id}/edit`}>Edit</Link>
          </Button>
          <form action={deleteCustomerWithId}>
            <Button type="submit" variant="destructive">
              Delete
            </Button>
          </form>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{formatAWG(totalSpent)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{customer.appointments.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Lead Source</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{titleCase(customer.leadSource)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Date Acquired</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{formatDate(customer.dateAcquired)}</p>
          </CardContent>
        </Card>
      </div>

      {customer.notes && (
        <Card>
          <CardHeader>
            <CardTitle>Notes</CardTitle>
          </CardHeader>
          <CardContent className="whitespace-pre-wrap text-sm text-foreground">{customer.notes}</CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Vehicles</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {customer.vehicles.length === 0 && (
            <p className="text-sm text-muted">No vehicles on file yet.</p>
          )}
          <div className="space-y-2">
            {customer.vehicles.map((v) => {
              const deleteVehicleWithIds = deleteVehicle.bind(null, customer.id, v.id);
              return (
                <div
                  key={v.id}
                  className="flex items-center justify-between rounded-lg border border-border px-3 py-2"
                >
                  <div>
                    <p className="text-sm font-medium text-ocean-950">
                      {v.year ? `${v.year} ` : ""}
                      {v.make} {v.model}
                    </p>
                    <p className="text-xs text-muted">
                      {titleCase(v.vehicleType)}
                      {v.color && ` · ${v.color}`}
                      {v.licensePlate && ` · ${v.licensePlate}`}
                    </p>
                  </div>
                  <form action={deleteVehicleWithIds}>
                    <Button type="submit" variant="ghost" size="sm">
                      Remove
                    </Button>
                  </form>
                </div>
              );
            })}
          </div>

          <details className="rounded-lg border border-dashed border-border p-3">
            <summary className="cursor-pointer text-sm font-medium text-ocean-700">
              + Add Vehicle
            </summary>
            <form action={addVehicleWithId} className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <Label htmlFor="make">Make *</Label>
                <Input id="make" name="make" required />
              </div>
              <div>
                <Label htmlFor="model">Model *</Label>
                <Input id="model" name="model" required />
              </div>
              <div>
                <Label htmlFor="year">Year</Label>
                <Input id="year" name="year" type="number" />
              </div>
              <div>
                <Label htmlFor="color">Color</Label>
                <Input id="color" name="color" />
              </div>
              <div>
                <Label htmlFor="licensePlate">License Plate</Label>
                <Input id="licensePlate" name="licensePlate" />
              </div>
              <div>
                <Label htmlFor="vehicleType">Vehicle Type</Label>
                <Select id="vehicleType" name="vehicleType" defaultValue="SEDAN">
                  {VEHICLE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {titleCase(t)}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label htmlFor="interiorMaterial">Interior Material</Label>
                <Input id="interiorMaterial" name="interiorMaterial" />
              </div>
              <div>
                <Label htmlFor="specialNotes">Special Notes</Label>
                <Input id="specialNotes" name="specialNotes" />
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <Button type="submit" size="sm">
                  Add Vehicle
                </Button>
              </div>
            </form>
          </details>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Appointments</CardTitle>
        </CardHeader>
        <CardContent>
          {customer.appointments.length === 0 ? (
            <p className="text-sm text-muted">No appointments yet.</p>
          ) : (
            <div className="divide-y divide-border">
              {customer.appointments.map((a) => (
                <Link
                  key={a.id}
                  href={`/admin/appointments/${a.id}`}
                  className="flex items-center justify-between py-3 hover:bg-ocean-50/40"
                >
                  <div>
                    <p className="text-sm font-medium text-ocean-950">
                      {a.vehicle.make} {a.vehicle.model}
                    </p>
                    <p className="text-xs text-muted">{formatDate(a.scheduledDate)}</p>
                  </div>
                  <Badge tone={apptStatusTone[a.status]}>{titleCase(a.status)}</Badge>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
