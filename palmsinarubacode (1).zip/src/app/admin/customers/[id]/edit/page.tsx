import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { updateCustomer } from "../../actions";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CUSTOMER_STATUSES, LEAD_SOURCES, CONTACT_METHODS } from "@/lib/enums";
import { titleCase } from "@/lib/utils";

export default async function EditCustomerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const customer = await prisma.customer.findUnique({ where: { id } });
  if (!customer) notFound();

  const updateWithId = updateCustomer.bind(null, customer.id);

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">Edit Customer</h1>
        <p className="text-sm text-muted">{customer.fullName}</p>
      </div>

      <Card>
        <CardContent className="pt-5">
          <form action={updateWithId} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="fullName">Full Name *</Label>
              <Input id="fullName" name="fullName" defaultValue={customer.fullName} required />
            </div>
            <div>
              <Label htmlFor="phone">Phone *</Label>
              <Input id="phone" name="phone" defaultValue={customer.phone} required />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" defaultValue={customer.email ?? ""} />
            </div>
            <div>
              <Label htmlFor="address">Address / Location</Label>
              <Input id="address" name="address" defaultValue={customer.address ?? ""} />
            </div>
            <div>
              <Label htmlFor="preferredContact">Preferred Contact</Label>
              <Select id="preferredContact" name="preferredContact" defaultValue={customer.preferredContact}>
                {CONTACT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {titleCase(m)}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="leadSource">Lead Source</Label>
              <Select id="leadSource" name="leadSource" defaultValue={customer.leadSource}>
                {LEAD_SOURCES.map((s) => (
                  <option key={s} value={s}>
                    {titleCase(s)}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select id="status" name="status" defaultValue={customer.status}>
                {CUSTOMER_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {titleCase(s)}
                  </option>
                ))}
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" name="notes" rows={3} defaultValue={customer.notes ?? ""} />
            </div>
            <div className="sm:col-span-2 flex justify-end gap-2">
              <Button type="submit">Save Changes</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
