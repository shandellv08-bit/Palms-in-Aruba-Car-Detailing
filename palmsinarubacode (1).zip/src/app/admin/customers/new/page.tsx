import { createCustomer } from "../actions";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CUSTOMER_STATUSES, LEAD_SOURCES, CONTACT_METHODS } from "@/lib/enums";
import { titleCase } from "@/lib/utils";

export default function NewCustomerPage() {
  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">New Customer</h1>
        <p className="text-sm text-muted">Add a customer to the database.</p>
      </div>

      <Card>
        <CardContent className="pt-5">
          <form action={createCustomer} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="fullName">Full Name *</Label>
              <Input id="fullName" name="fullName" required />
            </div>
            <div>
              <Label htmlFor="phone">Phone *</Label>
              <Input id="phone" name="phone" required />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" />
            </div>
            <div>
              <Label htmlFor="address">Address / Location</Label>
              <Input id="address" name="address" />
            </div>
            <div>
              <Label htmlFor="preferredContact">Preferred Contact</Label>
              <Select id="preferredContact" name="preferredContact" defaultValue="WHATSAPP">
                {CONTACT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {titleCase(m)}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="leadSource">Lead Source</Label>
              <Select id="leadSource" name="leadSource" defaultValue="OTHER">
                {LEAD_SOURCES.map((s) => (
                  <option key={s} value={s}>
                    {titleCase(s)}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select id="status" name="status" defaultValue="LEAD">
                {CUSTOMER_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {titleCase(s)}
                  </option>
                ))}
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" name="notes" rows={3} />
            </div>
            <div className="sm:col-span-2 flex justify-end gap-2">
              <Button type="submit">Create Customer</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
