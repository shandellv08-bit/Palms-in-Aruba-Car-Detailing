"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

function str(formData: FormData, key: string): string | undefined {
  const v = formData.get(key);
  return typeof v === "string" && v.trim() !== "" ? v.trim() : undefined;
}

export async function createCustomer(formData: FormData) {
  const fullName = str(formData, "fullName");
  const phone = str(formData, "phone");
  if (!fullName || !phone) throw new Error("Full name and phone are required.");

  const customer = await prisma.customer.create({
    data: {
      fullName,
      phone,
      email: str(formData, "email"),
      address: str(formData, "address"),
      preferredContact: (str(formData, "preferredContact") as never) ?? "WHATSAPP",
      leadSource: (str(formData, "leadSource") as never) ?? "OTHER",
      status: (str(formData, "status") as never) ?? "LEAD",
      notes: str(formData, "notes"),
    },
  });

  revalidatePath("/admin/customers");
  redirect(`/admin/customers/${customer.id}`);
}

export async function updateCustomer(id: string, formData: FormData) {
  const fullName = str(formData, "fullName");
  const phone = str(formData, "phone");
  if (!fullName || !phone) throw new Error("Full name and phone are required.");

  await prisma.customer.update({
    where: { id },
    data: {
      fullName,
      phone,
      email: str(formData, "email") ?? null,
      address: str(formData, "address") ?? null,
      preferredContact: (str(formData, "preferredContact") as never) ?? "WHATSAPP",
      leadSource: (str(formData, "leadSource") as never) ?? "OTHER",
      status: (str(formData, "status") as never) ?? "LEAD",
      notes: str(formData, "notes") ?? null,
    },
  });

  revalidatePath("/admin/customers");
  revalidatePath(`/admin/customers/${id}`);
  redirect(`/admin/customers/${id}`);
}

export async function deleteCustomer(id: string) {
  await prisma.customer.delete({ where: { id } });
  revalidatePath("/admin/customers");
  redirect("/admin/customers");
}

export async function addVehicle(customerId: string, formData: FormData) {
  const make = str(formData, "make");
  const model = str(formData, "model");
  if (!make || !model) throw new Error("Make and model are required.");

  const yearStr = str(formData, "year");

  await prisma.vehicle.create({
    data: {
      customerId,
      make,
      model,
      year: yearStr ? parseInt(yearStr, 10) : null,
      color: str(formData, "color"),
      licensePlate: str(formData, "licensePlate"),
      vehicleType: (str(formData, "vehicleType") as never) ?? "SEDAN",
      interiorMaterial: str(formData, "interiorMaterial"),
      specialNotes: str(formData, "specialNotes"),
      conditionNotes: str(formData, "conditionNotes"),
    },
  });

  revalidatePath(`/admin/customers/${customerId}`);
  revalidatePath("/admin/vehicles");
}

export async function deleteVehicle(customerId: string, vehicleId: string) {
  await prisma.vehicle.delete({ where: { id: vehicleId } });
  revalidatePath(`/admin/customers/${customerId}`);
  revalidatePath("/admin/vehicles");
}
