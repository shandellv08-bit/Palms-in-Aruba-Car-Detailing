import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatAWG, titleCase } from "@/lib/utils";
import { SERVICE_CATEGORIES } from "@/lib/enums";
import { createService, createAddOn, toggleServiceActive, toggleAddOnActive } from "./actions";
import { ToggleActive } from "./toggle-active";

export default async function ServicesPage() {
  const [services, addOns, laborRateSetting] = await Promise.all([
    prisma.service.findMany({ orderBy: { startingPrice: "asc" } }),
    prisma.addOn.findMany({ orderBy: { name: "asc" } }),
    prisma.businessSetting.findUnique({ where: { key: "labor_rate_per_hour" } }),
  ]);

  const laborRatePerHour = laborRateSetting ? parseFloat(laborRateSetting.value) : 20;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">Services & Pricing</h1>
        <p className="text-sm text-muted">
          Prices are fully configurable. Labor rate: {formatAWG(laborRatePerHour)}/hr (Settings).
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Services</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-2 py-2">Name</th>
                  <th className="px-2 py-2">Category</th>
                  <th className="px-2 py-2">Price</th>
                  <th className="px-2 py-2">Material</th>
                  <th className="px-2 py-2">Travel</th>
                  <th className="px-2 py-2">Labor</th>
                  <th className="px-2 py-2">Est. Profit</th>
                  <th className="px-2 py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {services.map((s) => {
                  const laborCost = (s.laborMinutes / 60) * laborRatePerHour;
                  const profit = Number(s.startingPrice) - Number(s.materialCost) - Number(s.travelCost) - laborCost;
                  const toggleWithId = toggleServiceActive.bind(null, s.id);
                  return (
                    <tr key={s.id}>
                      <td className="px-2 py-2 font-medium text-ocean-950">{s.name}</td>
                      <td className="px-2 py-2 text-muted">{titleCase(s.category)}</td>
                      <td className="px-2 py-2">{formatAWG(s.startingPrice)}</td>
                      <td className="px-2 py-2 text-muted">{formatAWG(s.materialCost)}</td>
                      <td className="px-2 py-2 text-muted">{formatAWG(s.travelCost)}</td>
                      <td className="px-2 py-2 text-muted">{formatAWG(laborCost)}</td>
                      <td className="px-2 py-2 font-medium text-ocean-800">{formatAWG(profit)}</td>
                      <td className="px-2 py-2">
                        <ToggleActive isActive={s.isActive} onToggle={toggleWithId} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <details className="rounded-lg border border-dashed border-border p-3">
            <summary className="cursor-pointer text-sm font-medium text-ocean-700">+ Add Service</summary>
            <form action={createService} className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="sm:col-span-3">
                <Label htmlFor="name">Name *</Label>
                <Input id="name" name="name" required />
              </div>
              <div className="sm:col-span-3">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" rows={2} />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Select id="category" name="category" defaultValue="BASIC">
                  {SERVICE_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {titleCase(c)}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label htmlFor="startingPrice">Starting Price (AWG)</Label>
                <Input id="startingPrice" name="startingPrice" type="number" step="0.01" required />
              </div>
              <div>
                <Label htmlFor="estimatedDuration">Duration (min)</Label>
                <Input id="estimatedDuration" name="estimatedDuration" type="number" required />
              </div>
              <div>
                <Label htmlFor="laborMinutes">Labor Time (min)</Label>
                <Input id="laborMinutes" name="laborMinutes" type="number" required />
              </div>
              <div>
                <Label htmlFor="materialCost">Material Cost (AWG)</Label>
                <Input id="materialCost" name="materialCost" type="number" step="0.01" />
              </div>
              <div>
                <Label htmlFor="travelCost">Travel Cost (AWG)</Label>
                <Input id="travelCost" name="travelCost" type="number" step="0.01" />
              </div>
              <div className="sm:col-span-3 flex justify-end">
                <Button type="submit" size="sm">
                  Add Service
                </Button>
              </div>
            </form>
          </details>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add-ons</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-2 py-2">Name</th>
                  <th className="px-2 py-2">Price</th>
                  <th className="px-2 py-2">Material Cost</th>
                  <th className="px-2 py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {addOns.map((a) => {
                  const toggleWithId = toggleAddOnActive.bind(null, a.id);
                  return (
                    <tr key={a.id}>
                      <td className="px-2 py-2 font-medium text-ocean-950">{a.name}</td>
                      <td className="px-2 py-2">{formatAWG(a.price)}</td>
                      <td className="px-2 py-2 text-muted">{formatAWG(a.materialCost)}</td>
                      <td className="px-2 py-2">
                        <ToggleActive isActive={a.isActive} onToggle={toggleWithId} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <details className="rounded-lg border border-dashed border-border p-3">
            <summary className="cursor-pointer text-sm font-medium text-ocean-700">+ Add Add-on</summary>
            <form action={createAddOn} className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <Label htmlFor="addonName">Name *</Label>
                <Input id="addonName" name="name" required />
              </div>
              <div>
                <Label htmlFor="price">Price (AWG)</Label>
                <Input id="price" name="price" type="number" step="0.01" required />
              </div>
              <div>
                <Label htmlFor="addonMaterialCost">Material Cost (AWG)</Label>
                <Input id="addonMaterialCost" name="materialCost" type="number" step="0.01" />
              </div>
              <div className="sm:col-span-3 flex justify-end">
                <Button type="submit" size="sm">
                  Add Add-on
                </Button>
              </div>
            </form>
          </details>
        </CardContent>
      </Card>
    </div>
  );
}
