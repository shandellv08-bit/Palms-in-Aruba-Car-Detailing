"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

function num(formData: FormData, key: string): number {
  const v = formData.get(key);
  return v ? parseFloat(v as string) : 0;
}
function str(formData: FormData, key: string): string | undefined {
  const v = formData.get(key);
  return typeof v === "string" && v.trim() !== "" ? v.trim() : undefined;
}

export async function createService(formData: FormData) {
  const name = str(formData, "name");
  if (!name) throw new Error("Name is required.");

  await prisma.service.create({
    data: {
      name,
      description: str(formData, "description"),
      category: (str(formData, "category") as never) ?? "BASIC",
      startingPrice: num(formData, "startingPrice"),
      estimatedDuration: num(formData, "estimatedDuration"),
      laborMinutes: num(formData, "laborMinutes"),
      materialCost: num(formData, "materialCost"),
      travelCost: num(formData, "travelCost"),
    },
  });
  revalidatePath("/admin/services");
}

export async function toggleServiceActive(id: string, isActive: boolean) {
  await prisma.service.update({ where: { id }, data: { isActive } });
  revalidatePath("/admin/services");
}

export async function updateServicePrice(id: string, formData: FormData) {
  await prisma.service.update({
    where: { id },
    data: {
      startingPrice: num(formData, "startingPrice"),
      materialCost: num(formData, "materialCost"),
      travelCost: num(formData, "travelCost"),
    },
  });
  revalidatePath("/admin/services");
}

export async function createAddOn(formData: FormData) {
  const name = str(formData, "name");
  if (!name) throw new Error("Name is required.");
  await prisma.addOn.create({
    data: {
      name,
      description: str(formData, "description"),
      price: num(formData, "price"),
      materialCost: num(formData, "materialCost"),
    },
  });
  revalidatePath("/admin/services");
}

export async function toggleAddOnActive(id: string, isActive: boolean) {
  await prisma.addOn.update({ where: { id }, data: { isActive } });
  revalidatePath("/admin/services");
}
