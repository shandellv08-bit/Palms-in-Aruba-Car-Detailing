"use client";

import { useTransition } from "react";

export function ToggleActive({
  isActive,
  onToggle,
}: {
  isActive: boolean;
  onToggle: (next: boolean) => Promise<void>;
}) {
  const [isPending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={isPending}
      onClick={() => startTransition(() => onToggle(!isActive))}
      className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
        isActive ? "bg-emerald-50 text-emerald-700" : "bg-ocean-50 text-muted"
      }`}
    >
      {isActive ? "Active" : "Inactive"}
    </button>
  );
}
