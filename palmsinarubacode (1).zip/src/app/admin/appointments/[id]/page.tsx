import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { formatAWG, formatDateTime, titleCase } from "@/lib/utils";
import { APPOINTMENT_STATUSES, PAYMENT_METHODS, REVIEW_PLATFORMS } from "@/lib/enums";
import { CHECKLIST_SECTION_LABELS } from "@/lib/checklist-template";
import {
  updateAppointmentStatus,
  recordPayment,
  updateReview,
  addPhoto,
} from "../actions";
import { ChecklistItemRow } from "./checklist-item";

const statusTone: Record<string, "neutral" | "positive" | "warning" | "negative" | "info"> = {
  INQUIRY: "neutral",
  QUOTED: "info",
  BOOKED: "info",
  CONFIRMED: "info",
  IN_PROGRESS: "warning",
  COMPLETED: "positive",
  CANCELLED: "negative",
  NO_SHOW: "negative",
};

export default async function AppointmentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const appointment = await prisma.appointment.findUnique({
    where: { id },
    include: {
      customer: true,
      vehicle: true,
      services: { include: { service: true } },
      addOns: { include: { addOn: true } },
      checklist: { orderBy: { sortOrder: "asc" } },
      payments: { orderBy: { paidAt: "desc" } },
      photos: { orderBy: { createdAt: "desc" } },
      review: true,
    },
  });

  if (!appointment) notFound();

  const updateStatusWithId = updateAppointmentStatus.bind(null, appointment.id);
  const recordPaymentWithId = recordPayment.bind(null, appointment.id);
  const updateReviewWithId = updateReview.bind(null, appointment.id);
  const addPhotoWithId = addPhoto.bind(null, appointment.id);

  const totalPaid = appointment.payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const price = Number(appointment.finalPrice ?? appointment.quotedPrice ?? 0);
  const balance = price - totalPaid;

  const sections = ["BEFORE_SERVICE", "EXTERIOR", "INTERIOR", "FINAL_INSPECTION"];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold text-ocean-950">
              {appointment.vehicle.make} {appointment.vehicle.model}
            </h1>
            <Badge tone={statusTone[appointment.status]}>{titleCase(appointment.status)}</Badge>
          </div>
          <p className="text-sm text-muted">
            <Link href={`/admin/customers/${appointment.customerId}`} className="hover:underline">
              {appointment.customer.fullName}
            </Link>{" "}
            · {formatDateTime(appointment.scheduledDate)}
            {appointment.location && ` · ${appointment.location}`}
          </p>
        </div>
        <form action={updateStatusWithId} className="flex gap-2">
          <Select key={appointment.status} name="status" defaultValue={appointment.status}>
            {APPOINTMENT_STATUSES.map((s) => (
              <option key={s} value={s}>
                {titleCase(s)}
              </option>
            ))}
          </Select>
          <Button type="submit" variant="outline">
            Update Status
          </Button>
        </form>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Card>
          <CardHeader>
            <CardTitle>Price</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{formatAWG(price)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Paid</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{formatAWG(totalPaid)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-semibold text-ocean-950">{formatAWG(balance)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Payment Status</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge tone={appointment.paymentStatus === "PAID" ? "positive" : "warning"}>
              {titleCase(appointment.paymentStatus)}
            </Badge>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Services & Add-ons</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1 text-sm">
          {appointment.services.map((s) => (
            <div key={s.id} className="flex justify-between">
              <span>{s.service.name}</span>
              <span className="text-muted">{formatAWG(s.priceAtBooking)}</span>
            </div>
          ))}
          {appointment.addOns.map((a) => (
            <div key={a.id} className="flex justify-between">
              <span>{a.addOn.name}</span>
              <span className="text-muted">{formatAWG(a.priceAtBooking)}</span>
            </div>
          ))}
          {appointment.notes && (
            <p className="mt-3 whitespace-pre-wrap border-t border-border pt-3 text-muted">
              {appointment.notes}
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Service Checklist</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {sections.map((section) => (
            <div key={section}>
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted">
                {CHECKLIST_SECTION_LABELS[section]}
              </p>
              {appointment.checklist
                .filter((item) => item.section === section)
                .map((item) => (
                  <ChecklistItemRow
                    key={item.id}
                    appointmentId={appointment.id}
                    itemId={item.id}
                    label={item.label}
                    isDone={item.isDone}
                  />
                ))}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Payments</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {appointment.payments.length > 0 && (
            <div className="space-y-1 text-sm">
              {appointment.payments.map((p) => (
                <div key={p.id} className="flex justify-between">
                  <span className="text-muted">
                    {formatDateTime(p.paidAt)} · {titleCase(p.method)}
                  </span>
                  <span className="font-medium text-ocean-950">{formatAWG(p.amount)}</span>
                </div>
              ))}
            </div>
          )}
          <form action={recordPaymentWithId} className="flex flex-wrap items-end gap-2">
            <div>
              <Label htmlFor="amount">Amount (AWG)</Label>
              <Input id="amount" name="amount" type="number" step="0.01" required className="w-32" />
            </div>
            <div>
              <Label htmlFor="method">Method</Label>
              <Select id="method" name="method" defaultValue="CASH" className="w-36">
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {titleCase(m)}
                  </option>
                ))}
              </Select>
            </div>
            <Button type="submit" size="sm">
              Record Payment
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Photos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {appointment.photos.length > 0 && (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {appointment.photos.map((p) => (
                <a key={p.id} href={p.url} target="_blank" rel="noreferrer" className="block">
                  <img src={p.url} alt={p.caption ?? p.stage} className="aspect-square w-full rounded-lg object-cover" />
                  <p className="mt-1 text-center text-xs text-muted">{titleCase(p.stage)}</p>
                </a>
              ))}
            </div>
          )}
          <form action={addPhotoWithId} className="flex flex-wrap items-end gap-2">
            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="url">Photo URL</Label>
              <Input id="url" name="url" placeholder="https://..." required />
            </div>
            <div>
              <Label htmlFor="stage">Stage</Label>
              <Select id="stage" name="stage" defaultValue="BEFORE" className="w-28">
                <option value="BEFORE">Before</option>
                <option value="AFTER">After</option>
              </Select>
            </div>
            <Button type="submit" size="sm">
              Add Photo
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Review</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p className="text-muted">
            Requested: {appointment.review?.requested ? "Yes" : "No"} · Received:{" "}
            {appointment.review?.received ? "Yes" : "No"}
            {appointment.review?.rating && ` · Rating: ${appointment.review.rating}/5`}
          </p>
          <div className="flex flex-wrap gap-3">
            <form action={updateReviewWithId}>
              <input type="hidden" name="action" value="request" />
              <Button type="submit" size="sm" variant="outline">
                Mark Review Requested
              </Button>
            </form>
            <form action={updateReviewWithId} className="flex flex-wrap items-end gap-2">
              <input type="hidden" name="action" value="received" />
              <Select name="platform" defaultValue="GOOGLE" className="w-32">
                {REVIEW_PLATFORMS.map((p) => (
                  <option key={p} value={p}>
                    {titleCase(p)}
                  </option>
                ))}
              </Select>
              <Select name="rating" defaultValue="5" className="w-20">
                {[5, 4, 3, 2, 1].map((r) => (
                  <option key={r} value={r}>
                    {r}★
                  </option>
                ))}
              </Select>
              <Textarea name="comment" placeholder="Comment (optional)" rows={1} className="w-48" />
              <Button type="submit" size="sm">
                Mark Received
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
