"use client";

import { useTransition } from "react";
import { toggleChecklistItem } from "../actions";

export function ChecklistItemRow({
  appointmentId,
  itemId,
  label,
  isDone,
}: {
  appointmentId: string;
  itemId: string;
  label: string;
  isDone: boolean;
}) {
  const [isPending, startTransition] = useTransition();

  return (
    <label className="flex items-center gap-2 py-1 text-sm">
      <input
        type="checkbox"
        defaultChecked={isDone}
        disabled={isPending}
        onChange={(e) =>
          startTransition(() => {
            toggleChecklistItem(appointmentId, itemId, e.target.checked);
          })
        }
      />
      <span className={isDone ? "text-muted line-through" : "text-foreground"}>{label}</span>
    </label>
  );
}
