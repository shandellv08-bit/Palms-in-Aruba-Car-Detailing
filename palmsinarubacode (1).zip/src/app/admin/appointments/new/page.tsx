import { prisma } from "@/lib/prisma";
import { AppointmentForm } from "./appointment-form";

export default async function NewAppointmentPage() {
  const [customers, services, addOns] = await Promise.all([
    prisma.customer.findMany({
      include: { vehicles: { select: { id: true, make: true, model: true, year: true } } },
      orderBy: { fullName: "asc" },
    }),
    prisma.service.findMany({ where: { isActive: true }, orderBy: { startingPrice: "asc" } }),
    prisma.addOn.findMany({ where: { isActive: true }, orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ocean-950">New Appointment</h1>
        <p className="text-sm text-muted">Book a service for a customer and vehicle on file.</p>
      </div>

      {customers.length === 0 ? (
        <p className="text-sm text-muted">
          Add a customer and vehicle first before creating an appointment.
        </p>
      ) : (
        <AppointmentForm
          customers={customers}
          services={services.map((s) => ({ id: s.id, name: s.name, startingPrice: Number(s.startingPrice) }))}
          addOns={addOns.map((a) => ({ id: a.id, name: a.name, price: Number(a.price) }))}
        />
      )}
    </div>
  );
}
