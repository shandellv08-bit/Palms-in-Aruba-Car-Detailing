"use client";

import { useMemo, useState } from "react";
import { createAppointment } from "../actions";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatAWG } from "@/lib/utils";

type Customer = {
  id: string;
  fullName: string;
  vehicles: { id: string; make: string; model: string; year: number | null }[];
};
type Service = { id: string; name: string; startingPrice: number };
type AddOn = { id: string; name: string; price: number };

export function AppointmentForm({
  customers,
  services,
  addOns,
}: {
  customers: Customer[];
  services: Service[];
  addOns: AddOn[];
}) {
  const [customerId, setCustomerId] = useState(customers[0]?.id ?? "");
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);

  const vehicles = useMemo(
    () => customers.find((c) => c.id === customerId)?.vehicles ?? [],
    [customers, customerId]
  );

  const estimatedTotal =
    services.filter((s) => selectedServices.includes(s.id)).reduce((sum, s) => sum + s.startingPrice, 0) +
    addOns.filter((a) => selectedAddOns.includes(a.id)).reduce((sum, a) => sum + a.price, 0);

  function toggle(list: string[], id: string, setter: (v: string[]) => void) {
    setter(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  }

  return (
    <Card>
      <CardContent className="pt-5">
        <form action={createAppointment} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="customerId">Customer *</Label>
            <Select
              id="customerId"
              name="customerId"
              required
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
            >
              {customers.length === 0 && <option value="">No customers yet</option>}
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="vehicleId">Vehicle *</Label>
            <Select id="vehicleId" name="vehicleId" required>
              {vehicles.length === 0 && <option value="">No vehicles on file</option>}
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.year ? `${v.year} ` : ""}
                  {v.make} {v.model}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="scheduledDate">Date & Time *</Label>
            <Input id="scheduledDate" name="scheduledDate" type="datetime-local" required />
          </div>
          <div>
            <Label htmlFor="location">Location</Label>
            <Input id="location" name="location" placeholder="e.g. Oranjestad" />
          </div>

          <div className="sm:col-span-2">
            <Label>Services</Label>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {services.map((s) => (
                <label
                  key={s.id}
                  className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm"
                >
                  <span className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      name="serviceIds"
                      value={s.id}
                      checked={selectedServices.includes(s.id)}
                      onChange={() => toggle(selectedServices, s.id, setSelectedServices)}
                    />
                    {s.name}
                  </span>
                  <span className="text-muted">{formatAWG(s.startingPrice)}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="sm:col-span-2">
            <Label>Add-ons</Label>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {addOns.map((a) => (
                <label
                  key={a.id}
                  className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm"
                >
                  <span className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      name="addOnIds"
                      value={a.id}
                      checked={selectedAddOns.includes(a.id)}
                      onChange={() => toggle(selectedAddOns, a.id, setSelectedAddOns)}
                    />
                    {a.name}
                  </span>
                  <span className="text-muted">{formatAWG(a.price)}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="sm:col-span-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" name="notes" rows={2} />
          </div>

          <div className="sm:col-span-2 flex items-center justify-between border-t border-border pt-4">
            <p className="text-sm text-muted">
              Estimated total: <span className="font-semibold text-ocean-950">{formatAWG(estimatedTotal)}</span>
            </p>
            <Button type="submit" disabled={customers.length === 0}>
              Create Appointment
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
