"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { CHECKLIST_TEMPLATE } from "@/lib/checklist-template";

function str(formData: FormData, key: string): string | undefined {
  const v = formData.get(key);
  return typeof v === "string" && v.trim() !== "" ? v.trim() : undefined;
}

export async function createAppointment(formData: FormData) {
  const customerId = str(formData, "customerId");
  const vehicleId = str(formData, "vehicleId");
  const scheduledDate = str(formData, "scheduledDate");
  if (!customerId || !vehicleId || !scheduledDate) {
    throw new Error("Customer, vehicle, and date/time are required.");
  }

  const serviceIds = formData.getAll("serviceIds").filter((v): v is string => typeof v === "string");
  const addOnIds = formData.getAll("addOnIds").filter((v): v is string => typeof v === "string");

  const [services, addOns] = await Promise.all([
    prisma.service.findMany({ where: { id: { in: serviceIds } } }),
    prisma.addOn.findMany({ where: { id: { in: addOnIds } } }),
  ]);

  const quotedPrice =
    services.reduce((sum, s) => sum + Number(s.startingPrice), 0) +
    addOns.reduce((sum, a) => sum + Number(a.price), 0);

  const estimatedDuration = services.reduce((sum, s) => sum + s.estimatedDuration, 0);

  const appointment = await prisma.appointment.create({
    data: {
      customerId,
      vehicleId,
      scheduledDate: new Date(scheduledDate),
      location: str(formData, "location"),
      notes: str(formData, "notes"),
      quotedPrice,
      estimatedDuration: estimatedDuration || null,
      status: "BOOKED",
      services: {
        create: services.map((s) => ({ serviceId: s.id, priceAtBooking: s.startingPrice })),
      },
      addOns: {
        create: addOns.map((a) => ({ addOnId: a.id, priceAtBooking: a.price })),
      },
      checklist: {
        create: CHECKLIST_TEMPLATE.map((item, i) => ({
          section: item.section as never,
          label: item.label,
          sortOrder: i,
        })),
      },
    },
  });

  revalidatePath("/admin/appointments");
  redirect(`/admin/appointments/${appointment.id}`);
}

export async function updateAppointmentStatus(id: string, formData: FormData) {
  const status = str(formData, "status");
  if (!status) return;

  await prisma.appointment.update({ where: { id }, data: { status: status as never } });

  if (status === "COMPLETED") {
    const appointment = await prisma.appointment.findUnique({ where: { id } });
    if (appointment) {
      await prisma.job.upsert({
        where: { appointmentId: id },
        update: { completedAt: new Date() },
        create: { appointmentId: id, completedAt: new Date(), startedAt: new Date() },
      });
      await prisma.review.upsert({
        where: { appointmentId: id },
        update: {},
        create: { appointmentId: id, customerId: appointment.customerId },
      });
      if (!appointment.finalPrice && appointment.quotedPrice) {
        await prisma.appointment.update({
          where: { id },
          data: { finalPrice: appointment.quotedPrice },
        });
      }
      // bump customer status toward active
      const customer = await prisma.customer.findUnique({ where: { id: appointment.customerId } });
      if (customer && (customer.status === "LEAD" || customer.status === "NEW")) {
        await prisma.customer.update({ where: { id: customer.id }, data: { status: "ACTIVE" } });
      }
      await prisma.vehicle.update({
        where: { id: appointment.vehicleId },
        data: { lastDetailed: new Date() },
      });
    }
  }

  revalidatePath(`/admin/appointments/${id}`);
  revalidatePath("/admin/appointments");
}

export async function toggleChecklistItem(appointmentId: string, itemId: string, isDone: boolean) {
  await prisma.checklistItem.update({ where: { id: itemId }, data: { isDone } });
  revalidatePath(`/admin/appointments/${appointmentId}`);
}

export async function recordPayment(appointmentId: string, formData: FormData) {
  const amountStr = str(formData, "amount");
  if (!amountStr) throw new Error("Amount is required.");
  const amount = parseFloat(amountStr);

  const appointment = await prisma.appointment.findUnique({ where: { id: appointmentId } });
  if (!appointment) throw new Error("Appointment not found.");

  await prisma.payment.create({
    data: {
      appointmentId,
      customerId: appointment.customerId,
      amount,
      method: (str(formData, "method") as never) ?? "CASH",
      notes: str(formData, "notes"),
    },
  });

  const paidAgg = await prisma.payment.aggregate({
    _sum: { amount: true },
    where: { appointmentId },
  });
  const totalPaid = Number(paidAgg._sum.amount ?? 0);
  const target = Number(appointment.finalPrice ?? appointment.quotedPrice ?? 0);
  const paymentStatus = totalPaid <= 0 ? "UNPAID" : totalPaid >= target && target > 0 ? "PAID" : "PARTIAL";

  await prisma.appointment.update({
    where: { id: appointmentId },
    data: { paymentStatus },
  });

  revalidatePath(`/admin/appointments/${appointmentId}`);
}

export async function updateReview(appointmentId: string, formData: FormData) {
  const action = str(formData, "action");
  const appointment = await prisma.appointment.findUnique({ where: { id: appointmentId } });
  if (!appointment) return;

  if (action === "request") {
    await prisma.review.upsert({
      where: { appointmentId },
      update: { requested: true, requestedAt: new Date() },
      create: {
        appointmentId,
        customerId: appointment.customerId,
        requested: true,
        requestedAt: new Date(),
      },
    });
  } else if (action === "received") {
    await prisma.review.upsert({
      where: { appointmentId },
      update: {
        received: true,
        receivedAt: new Date(),
        platform: (str(formData, "platform") as never) ?? undefined,
        rating: str(formData, "rating") ? parseInt(str(formData, "rating")!, 10) : undefined,
        comment: str(formData, "comment"),
      },
      create: {
        appointmentId,
        customerId: appointment.customerId,
        received: true,
        receivedAt: new Date(),
        platform: (str(formData, "platform") as never) ?? undefined,
        rating: str(formData, "rating") ? parseInt(str(formData, "rating")!, 10) : undefined,
        comment: str(formData, "comment"),
      },
    });
  }

  revalidatePath(`/admin/appointments/${appointmentId}`);
  revalidatePath("/admin/reviews");
}

export async function addPhoto(appointmentId: string, formData: FormData) {
  const url = str(formData, "url");
  const stage = str(formData, "stage") ?? "BEFORE";
  if (!url) return;
  await prisma.photo.create({
    data: { appointmentId, url, stage: stage as never, caption: str(formData, "caption") },
  });
  revalidatePath(`/admin/appointments/${appointmentId}`);
}
