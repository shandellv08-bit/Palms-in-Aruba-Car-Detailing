import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/input";
import { formatAWG, formatDateTime, titleCase } from "@/lib/utils";
import { APPOINTMENT_STATUSES } from "@/lib/enums";

const statusTone: Record<string, "neutral" | "positive" | "warning" | "negative" | "info"> = {
  INQUIRY: "neutral",
  QUOTED: "info",
  BOOKED: "info",
  CONFIRMED: "info",
  IN_PROGRESS: "warning",
  COMPLETED: "positive",
  CANCELLED: "negative",
  NO_SHOW: "negative",
};

export default async function AppointmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;

  const appointments = await prisma.appointment.findMany({
    where: status ? { status: status as never } : undefined,
    include: { customer: true, vehicle: true },
    orderBy: { scheduledDate: "desc" },
    take: 100,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-ocean-950">Appointments</h1>
          <p className="text-sm text-muted">{appointments.length} shown</p>
        </div>
        <Button asChild>
          <Link href="/admin/appointments/new">+ New Appointment</Link>
        </Button>
      </div>

      <form className="flex gap-3">
        <Select name="status" defaultValue={status} className="max-w-[200px]">
          <option value="">All statuses</option>
          {APPOINTMENT_STATUSES.map((s) => (
            <option key={s} value={s}>
              {titleCase(s)}
            </option>
          ))}
        </Select>
        <Button type="submit" variant="outline">
          Filter
        </Button>
      </form>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-ocean-50/50 text-left text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Vehicle</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Payment</th>
              <th className="px-4 py-3">Price</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {appointments.map((a) => (
              <tr key={a.id} className="hover:bg-ocean-50/40">
                <td className="px-4 py-3 text-muted">{formatDateTime(a.scheduledDate)}</td>
                <td className="px-4 py-3">
                  <Link href={`/admin/appointments/${a.id}`} className="font-medium text-ocean-800 hover:underline">
                    {a.customer.fullName}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">
                  {a.vehicle.make} {a.vehicle.model}
                </td>
                <td className="px-4 py-3">
                  <Badge tone={statusTone[a.status]}>{titleCase(a.status)}</Badge>
                </td>
                <td className="px-4 py-3 text-muted">{titleCase(a.paymentStatus)}</td>
                <td className="px-4 py-3 font-medium text-ocean-950">
                  {formatAWG(a.finalPrice ?? a.quotedPrice)}
                </td>
              </tr>
            ))}
            {appointments.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted">
                  No appointments found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
