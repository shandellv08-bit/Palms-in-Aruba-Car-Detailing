import { auth, signOut } from "@/auth";
import { AdminNav } from "@/components/admin/nav";
import { redirect } from "next/navigation";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 shrink-0 bg-ocean-950 md:block">
        <div className="border-b border-ocean-800 px-5 py-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-sand-400">
            Palms in Aruba
          </p>
          <p className="text-sm text-ocean-100">Car Detailing System</p>
        </div>
        <AdminNav />
      </aside>
      <div className="flex min-h-screen flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-border bg-white px-6 py-3">
          <p className="text-sm text-muted">
            Signed in as <span className="font-medium text-foreground">{session.user.name}</span>
          </p>
          <form
            action={async () => {
              "use server";
              await signOut({ redirectTo: "/login" });
            }}
          >
            <button className="text-sm text-muted hover:text-ocean-700">Sign out</button>
          </form>
        </header>
        <main className="flex-1 bg-background p-6">{children}</main>
      </div>
    </div>
  );
}
