import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

const tones = {
  neutral: "bg-ocean-50 text-ocean-800",
  positive: "bg-emerald-50 text-emerald-700",
  warning: "bg-sand-100 text-sand-500",
  negative: "bg-red-50 text-red-700",
  info: "bg-ocean-100 text-ocean-700",
};

export function Badge({
  className,
  tone = "neutral",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: keyof typeof tones }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        tones[tone],
        className
      )}
      {...props}
    />
  );
}
