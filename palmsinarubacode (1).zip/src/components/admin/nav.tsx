"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Megaphone,
  Users,
  Wrench,
  DollarSign,
  Settings,
  Calendar,
  Car,
  ClipboardList,
  Package,
  Star,
  Gift,
  BarChart3,
  Repeat,
} from "lucide-react";

const sections = [
  {
    title: "",
    items: [{ href: "/admin", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    title: "Marketing",
    items: [
      { href: "/admin/marketing/leads", label: "Leads", icon: Megaphone },
      { href: "/admin/marketing/campaigns", label: "Campaigns", icon: BarChart3 },
      { href: "/admin/marketing/content", label: "Content", icon: ClipboardList },
      { href: "/admin/marketing/referrals", label: "Referrals", icon: Gift },
    ],
  },
  {
    title: "Operations",
    items: [
      { href: "/admin/appointments", label: "Calendar & Appointments", icon: Calendar },
      { href: "/admin/customers", label: "Customers", icon: Users },
      { href: "/admin/vehicles", label: "Vehicles", icon: Car },
      { href: "/admin/services", label: "Services", icon: Wrench },
      { href: "/admin/inventory", label: "Inventory", icon: Package },
      { href: "/admin/reviews", label: "Reviews", icon: Star },
      { href: "/admin/recurring", label: "Recurring", icon: Repeat },
    ],
  },
  {
    title: "Finance",
    items: [
      { href: "/admin/finance", label: "Revenue / Expenses / Profit", icon: DollarSign },
    ],
  },
  {
    title: "Settings",
    items: [{ href: "/admin/settings", label: "Business & Targets", icon: Settings }],
  },
];

export function AdminNav() {
  const pathname = usePathname();
  return (
    <nav className="flex flex-col gap-5 p-4">
      {sections.map((section) => (
        <div key={section.title || "root"}>
          {section.title && (
            <p className="mb-1 px-3 text-[11px] font-semibold uppercase tracking-widest text-ocean-300">
              {section.title}
            </p>
          )}
          <div className="flex flex-col gap-0.5">
            {section.items.map((item) => {
              const active =
                pathname === item.href ||
                (item.href !== "/admin" && pathname.startsWith(item.href));
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-ocean-700 text-white"
                      : "text-ocean-100 hover:bg-ocean-800"
                  )}
                >
                  <Icon size={16} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}
